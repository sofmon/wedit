// Copyright (c) 2016, Haralampi Staykov (http://haralampi.com). All rights reserved.
// Use of this source code is governed by MIT license that can be found in the LICENSE file.

package generator

// Element represents an html element on a page
type Element struct {

	// The unique element key in the HTML
	Key string `json:"k"`

	// The text of the element
	Text string `json:"t"`
}

// Image represents an image on a page
type Image struct {

	// The unique element key in the HTML
	Key string `json:"k"`

	// The serving src for the image
	Src string `json:"s"`
}

// Repeat represents a repeatable element on a page
type Repeat struct {
	// The unique element key in the HTML
	Key string `json:"k"`

	// Comma separated list of keys of elements that are children of this element
	CopyKeys string `json:"ck"`
}

// Page represents an html page
type Page struct {

	// The page title
	Title string `json:"t"`

	// The page repeat elements
	Repeats []Repeat `json:"r"`

	// The page variable elements
	Elements []Element `json:"e"`

	// The page variable elements
	Images []Image `json:"i"`
}

// NewEmptyPage creates a new empty page
func NewEmptyPage() *Page {
	return &Page{
		Title:    "",
		Repeats:  []Repeat{},
		Elements: []Element{},
		Images:   []Image{},
	}
}
